﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.tbTotal = New System.Windows.Forms.TextBox()
        Me.dgvProduto = New System.Windows.Forms.DataGridView()
        Me.btnPagamento = New System.Windows.Forms.Button()
        Me.btnPao = New System.Windows.Forms.Button()
        Me.btnCafe = New System.Windows.Forms.Button()
        Me.btnPastel = New System.Windows.Forms.Button()
        Me.btnRissol = New System.Windows.Forms.Button()
        Me.btnBolos = New System.Windows.Forms.Button()
        Me.btnFinos = New System.Windows.Forms.Button()
        Me.btnSumo = New System.Windows.Forms.Button()
        Me.btnCocktails = New System.Windows.Forms.Button()
        Me.TabPage4.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        CType(Me.dgvProduto, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TabPage4
        '
        Me.TabPage4.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TabPage4.Controls.Add(Me.btnSumo)
        Me.TabPage4.Controls.Add(Me.btnCocktails)
        Me.TabPage4.Location = New System.Drawing.Point(4, 24)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Size = New System.Drawing.Size(265, 320)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Bebidas"
        '
        'TabPage3
        '
        Me.TabPage3.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TabPage3.Controls.Add(Me.btnBolos)
        Me.TabPage3.Controls.Add(Me.btnFinos)
        Me.TabPage3.Location = New System.Drawing.Point(4, 24)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(265, 320)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Doces"
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TabPage2.Controls.Add(Me.btnPastel)
        Me.TabPage2.Controls.Add(Me.btnRissol)
        Me.TabPage2.Location = New System.Drawing.Point(4, 24)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(265, 320)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Salgados"
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TabPage1.Controls.Add(Me.btnPao)
        Me.TabPage1.Controls.Add(Me.btnCafe)
        Me.TabPage1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabPage1.ForeColor = System.Drawing.Color.SaddleBrown
        Me.TabPage1.Location = New System.Drawing.Point(4, 24)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(265, 320)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Café"
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl1.Location = New System.Drawing.Point(9, 6)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(273, 348)
        Me.TabControl1.TabIndex = 13
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(415, 358)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(50, 17)
        Me.Label1.TabIndex = 14
        Me.Label1.Text = "Total:"
        '
        'tbTotal
        '
        Me.tbTotal.Location = New System.Drawing.Point(463, 358)
        Me.tbTotal.Name = "tbTotal"
        Me.tbTotal.Size = New System.Drawing.Size(102, 20)
        Me.tbTotal.TabIndex = 15
        Me.tbTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'dgvProduto
        '
        Me.dgvProduto.BackgroundColor = System.Drawing.SystemColors.ControlDarkDark
        Me.dgvProduto.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvProduto.Location = New System.Drawing.Point(278, 26)
        Me.dgvProduto.Name = "dgvProduto"
        Me.dgvProduto.Size = New System.Drawing.Size(290, 326)
        Me.dgvProduto.TabIndex = 16
        '
        'btnPagamento
        '
        Me.btnPagamento.BackColor = System.Drawing.Color.Silver
        Me.btnPagamento.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPagamento.Location = New System.Drawing.Point(463, 384)
        Me.btnPagamento.Name = "btnPagamento"
        Me.btnPagamento.Size = New System.Drawing.Size(102, 33)
        Me.btnPagamento.TabIndex = 17
        Me.btnPagamento.Text = "&Pagamento"
        Me.btnPagamento.UseVisualStyleBackColor = False
        '
        'btnPao
        '
        Me.btnPao.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPao.ForeColor = System.Drawing.Color.White
        Me.btnPao.Image = Global.Pao_Quente.My.Resources.Resources.Pao
        Me.btnPao.Location = New System.Drawing.Point(108, 16)
        Me.btnPao.Name = "btnPao"
        Me.btnPao.Size = New System.Drawing.Size(75, 69)
        Me.btnPao.TabIndex = 1
        Me.btnPao.Text = "Pão"
        Me.btnPao.UseVisualStyleBackColor = True
        '
        'btnCafe
        '
        Me.btnCafe.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCafe.ForeColor = System.Drawing.Color.SeaShell
        Me.btnCafe.Image = Global.Pao_Quente.My.Resources.Resources.cafe
        Me.btnCafe.Location = New System.Drawing.Point(16, 16)
        Me.btnCafe.Name = "btnCafe"
        Me.btnCafe.Size = New System.Drawing.Size(75, 69)
        Me.btnCafe.TabIndex = 0
        Me.btnCafe.Text = "Café"
        Me.btnCafe.UseVisualStyleBackColor = True
        '
        'btnPastel
        '
        Me.btnPastel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPastel.ForeColor = System.Drawing.Color.White
        Me.btnPastel.Image = Global.Pao_Quente.My.Resources.Resources.pastel
        Me.btnPastel.Location = New System.Drawing.Point(106, 16)
        Me.btnPastel.Name = "btnPastel"
        Me.btnPastel.Size = New System.Drawing.Size(75, 69)
        Me.btnPastel.TabIndex = 2
        Me.btnPastel.Text = "Pasteis Bacalhau"
        Me.btnPastel.UseVisualStyleBackColor = True
        '
        'btnRissol
        '
        Me.btnRissol.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRissol.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnRissol.Image = Global.Pao_Quente.My.Resources.Resources.rissol
        Me.btnRissol.Location = New System.Drawing.Point(16, 16)
        Me.btnRissol.Name = "btnRissol"
        Me.btnRissol.Size = New System.Drawing.Size(75, 69)
        Me.btnRissol.TabIndex = 1
        Me.btnRissol.Text = "Rissol"
        Me.btnRissol.UseVisualStyleBackColor = True
        '
        'btnBolos
        '
        Me.btnBolos.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBolos.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnBolos.Image = Global.Pao_Quente.My.Resources.Resources.queque
        Me.btnBolos.Location = New System.Drawing.Point(106, 17)
        Me.btnBolos.Margin = New System.Windows.Forms.Padding(1, 3, 1, 3)
        Me.btnBolos.Name = "btnBolos"
        Me.btnBolos.Size = New System.Drawing.Size(75, 69)
        Me.btnBolos.TabIndex = 2
        Me.btnBolos.Text = "Bolos"
        Me.btnBolos.UseVisualStyleBackColor = True
        '
        'btnFinos
        '
        Me.btnFinos.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnFinos.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnFinos.Image = Global.Pao_Quente.My.Resources.Resources.bolo1
        Me.btnFinos.Location = New System.Drawing.Point(16, 16)
        Me.btnFinos.Name = "btnFinos"
        Me.btnFinos.Size = New System.Drawing.Size(75, 69)
        Me.btnFinos.TabIndex = 1
        Me.btnFinos.Text = "Bolos Finos"
        Me.btnFinos.UseVisualStyleBackColor = True
        '
        'btnSumo
        '
        Me.btnSumo.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSumo.ForeColor = System.Drawing.SystemColors.Window
        Me.btnSumo.Image = Global.Pao_Quente.My.Resources.Resources.sumo
        Me.btnSumo.Location = New System.Drawing.Point(104, 18)
        Me.btnSumo.Name = "btnSumo"
        Me.btnSumo.Size = New System.Drawing.Size(75, 69)
        Me.btnSumo.TabIndex = 2
        Me.btnSumo.Text = "Sumos"
        Me.btnSumo.UseCompatibleTextRendering = True
        Me.btnSumo.UseVisualStyleBackColor = True
        '
        'btnCocktails
        '
        Me.btnCocktails.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCocktails.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnCocktails.Image = Global.Pao_Quente.My.Resources.Resources.bebidas11
        Me.btnCocktails.Location = New System.Drawing.Point(13, 18)
        Me.btnCocktails.Name = "btnCocktails"
        Me.btnCocktails.Size = New System.Drawing.Size(75, 69)
        Me.btnCocktails.TabIndex = 1
        Me.btnCocktails.Text = "Cocktails"
        Me.btnCocktails.UseCompatibleTextRendering = True
        Me.btnCocktails.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(576, 423)
        Me.Controls.Add(Me.btnPagamento)
        Me.Controls.Add(Me.dgvProduto)
        Me.Controls.Add(Me.tbTotal)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.TabControl1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.Text = "Pão Quente - Café"
        Me.TabPage4.ResumeLayout(False)
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabControl1.ResumeLayout(False)
        CType(Me.dgvProduto, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents TabPage4 As TabPage
    Friend WithEvents btnSumo As Button
    Friend WithEvents btnCocktails As Button
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents btnBolos As Button
    Friend WithEvents btnFinos As Button
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents btnPastel As Button
    Friend WithEvents btnRissol As Button
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents btnPao As Button
    Friend WithEvents btnCafe As Button
    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents Label1 As Label
    Friend WithEvents tbTotal As TextBox
    Friend WithEvents dgvProduto As DataGridView
    Friend WithEvents btnPagamento As Button
End Class
