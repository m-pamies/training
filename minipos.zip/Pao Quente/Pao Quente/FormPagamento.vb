﻿Public Class FormPagamento

    Private Sub FormPagamento_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        InicializarGrid()
        tbTotPagamento.ReadOnly = True
    End Sub

    Private Sub InicializarGrid()
        With dgvProdPg
            .RowHeadersVisible = False
            .AllowUserToAddRows = False
            .AllowUserToDeleteRows = False
            .AllowUserToResizeColumns = False
            .AllowUserToResizeRows = False
            .MultiSelect = False
            .ReadOnly = True
            .Font = New Font("Tahoma", 10.25)
            .Columns(0).Width = 105
            .Columns(1).Width = 40
            .Columns(2).Width = 50
            .Columns(3).Width = 50
            .Columns(0).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
            .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
            .Columns(1).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
            .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
            .Columns(2).HeaderCell.Style.Alignment = DataGridViewContentAlignment.TopRight
            .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopRight
            .Columns(3).HeaderCell.Style.Alignment = DataGridViewContentAlignment.TopRight
            .Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopRight

        End With
    End Sub

    Private Sub btnCancelar_Click(sender As Object, e As EventArgs) Handles btnCancelar.Click
        Close()
    End Sub

    Private Sub btnImprimir_Click(sender As Object, e As EventArgs) Handles btnImprimir.Click
        PrintDocument1.Print()
        Form1.pagamentoEfetuado = True
        Close()
    End Sub
    'função para identificar o radiobutton selecionado
    Private Function GetGroupBoxCheckedButton(grpb As GroupBox) As RadioButton
        Dim rButton As RadioButton =
            grpb.Controls.OfType(Of RadioButton).FirstOrDefault(Function(r) r.Checked = True)
        Return rButton
    End Function

    Private Sub PrintDocument1_PrintPage(sender As Object, e As Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage
        Dim s1 As String
        Dim s2 As String
        Dim s3 As String
        Dim s4 As String
        'Dim row = Me.dgvProdutos1.CurrentCell.RowIndex

        s1 = "Pão Quente" & vbCrLf
        s2 = "Fatura: " & Now
        s3 = "NIF: " & mtbNIF.Text & vbCrLf
        s3 = s3 & "Nome: " & tbNome.Text & vbCrLf
        s3 = s3 & "Forma de Pagamento: " & GetGroupBoxCheckedButton(gbPagamentos).Text & vbCrLf
        s3 = s3 & "" & vbCrLf
        s3 = s3 & "Produtos          Quant    P.Unid    P.Total" & vbCrLf
        s3 = s3 & "---------------------------------------------------------" & vbCrLf
        s4 = "-----------------------------------------------------------" & vbCrLf
        s4 = s4 & "Total:                                                € " & tbTotPagamento.Text & vbCrLf
        e.Graphics.DrawString(s1, New Font("arial", 16, FontStyle.Bold Or FontStyle.Underline), Brushes.Orange, 100, 50)
        e.Graphics.DrawString(s2, New Font("arial", 12, FontStyle.Bold), Brushes.Blue, 50, 100)
        e.Graphics.DrawString(s3, New Font("arial", 12, FontStyle.Bold), Brushes.Black, 50, 150)

        Dim linha As Integer = 265
        For Each row As DataGridViewRow In dgvProdPg.Rows
            e.Graphics.DrawString(row.Cells(0).Value, New Font("arial", 12, FontStyle.Bold), Brushes.Black, 50, linha)
            e.Graphics.DrawString(row.Cells(1).Value, New Font("arial", 12, FontStyle.Bold), Brushes.Black, 200, linha)
            e.Graphics.DrawString(row.Cells(2).Value, New Font("arial", 12, FontStyle.Bold), Brushes.Black, 245, linha)
            e.Graphics.DrawString(row.Cells(3).Value, New Font("arial", 12, FontStyle.Bold), Brushes.Black, 320, linha)
            linha += 15
        Next

        linha += 50

        e.Graphics.DrawString(s4, New Font("arial", 12, FontStyle.Bold), Brushes.Black, 50, linha)
    End Sub

    Private Sub rbCheque_CheckedChanged(sender As Object, e As EventArgs) Handles rbCredito.CheckedChanged

    End Sub
End Class