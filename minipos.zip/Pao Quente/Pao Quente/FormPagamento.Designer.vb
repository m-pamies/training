﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormPagamento
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnCancelar = New System.Windows.Forms.Button()
        Me.btnImprimir = New System.Windows.Forms.Button()
        Me.dgvProdPg = New System.Windows.Forms.DataGridView()
        Me.tbTotPagamento = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.gbDadosCliente = New System.Windows.Forms.GroupBox()
        Me.tbNome = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.mtbNIF = New System.Windows.Forms.MaskedTextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.gbPagamentos = New System.Windows.Forms.GroupBox()
        Me.rbCredito = New System.Windows.Forms.RadioButton()
        Me.rbMBWay = New System.Windows.Forms.RadioButton()
        Me.rbMB = New System.Windows.Forms.RadioButton()
        Me.rbDinheiro = New System.Windows.Forms.RadioButton()
        Me.PrintDocument1 = New System.Drawing.Printing.PrintDocument()
        CType(Me.dgvProdPg, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gbDadosCliente.SuspendLayout()
        Me.gbPagamentos.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnCancelar
        '
        Me.btnCancelar.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold)
        Me.btnCancelar.Location = New System.Drawing.Point(229, 290)
        Me.btnCancelar.Name = "btnCancelar"
        Me.btnCancelar.Size = New System.Drawing.Size(92, 30)
        Me.btnCancelar.TabIndex = 22
        Me.btnCancelar.Text = "Cancelar"
        Me.btnCancelar.UseVisualStyleBackColor = True
        '
        'btnImprimir
        '
        Me.btnImprimir.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold)
        Me.btnImprimir.Location = New System.Drawing.Point(337, 290)
        Me.btnImprimir.Name = "btnImprimir"
        Me.btnImprimir.Size = New System.Drawing.Size(92, 30)
        Me.btnImprimir.TabIndex = 21
        Me.btnImprimir.Text = "Imprimir"
        Me.btnImprimir.UseVisualStyleBackColor = True
        '
        'dgvProdPg
        '
        Me.dgvProdPg.BackgroundColor = System.Drawing.SystemColors.ControlLightLight
        Me.dgvProdPg.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvProdPg.Location = New System.Drawing.Point(183, 12)
        Me.dgvProdPg.Name = "dgvProdPg"
        Me.dgvProdPg.Size = New System.Drawing.Size(246, 244)
        Me.dgvProdPg.TabIndex = 20
        '
        'tbTotPagamento
        '
        Me.tbTotPagamento.Location = New System.Drawing.Point(337, 261)
        Me.tbTotPagamento.Name = "tbTotPagamento"
        Me.tbTotPagamento.Size = New System.Drawing.Size(92, 20)
        Me.tbTotPagamento.TabIndex = 19
        Me.tbTotPagamento.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.Label3.Location = New System.Drawing.Point(277, 261)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(44, 17)
        Me.Label3.TabIndex = 18
        Me.Label3.Text = "Total:"
        '
        'gbDadosCliente
        '
        Me.gbDadosCliente.Controls.Add(Me.tbNome)
        Me.gbDadosCliente.Controls.Add(Me.Label2)
        Me.gbDadosCliente.Controls.Add(Me.mtbNIF)
        Me.gbDadosCliente.Controls.Add(Me.Label1)
        Me.gbDadosCliente.Location = New System.Drawing.Point(9, 164)
        Me.gbDadosCliente.Name = "gbDadosCliente"
        Me.gbDadosCliente.Size = New System.Drawing.Size(166, 158)
        Me.gbDadosCliente.TabIndex = 17
        Me.gbDadosCliente.TabStop = False
        Me.gbDadosCliente.Text = "Dados do Cliente"
        '
        'tbNome
        '
        Me.tbNome.Location = New System.Drawing.Point(11, 113)
        Me.tbNome.Name = "tbNome"
        Me.tbNome.Size = New System.Drawing.Size(138, 20)
        Me.tbNome.TabIndex = 4
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(9, 97)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(38, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Nome:"
        '
        'mtbNIF
        '
        Me.mtbNIF.Location = New System.Drawing.Point(12, 50)
        Me.mtbNIF.Mask = "000000000"
        Me.mtbNIF.Name = "mtbNIF"
        Me.mtbNIF.Size = New System.Drawing.Size(61, 20)
        Me.mtbNIF.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(11, 34)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(30, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "NIF.:"
        '
        'gbPagamentos
        '
        Me.gbPagamentos.Controls.Add(Me.rbCredito)
        Me.gbPagamentos.Controls.Add(Me.rbMBWay)
        Me.gbPagamentos.Controls.Add(Me.rbMB)
        Me.gbPagamentos.Controls.Add(Me.rbDinheiro)
        Me.gbPagamentos.Location = New System.Drawing.Point(9, 3)
        Me.gbPagamentos.Name = "gbPagamentos"
        Me.gbPagamentos.Size = New System.Drawing.Size(166, 135)
        Me.gbPagamentos.TabIndex = 16
        Me.gbPagamentos.TabStop = False
        Me.gbPagamentos.Text = "Forma de Pagamento"
        '
        'rbCredito
        '
        Me.rbCredito.AutoSize = True
        Me.rbCredito.Location = New System.Drawing.Point(12, 102)
        Me.rbCredito.Name = "rbCredito"
        Me.rbCredito.Size = New System.Drawing.Size(92, 17)
        Me.rbCredito.TabIndex = 3
        Me.rbCredito.TabStop = True
        Me.rbCredito.Text = "Cartão Crédito"
        Me.rbCredito.UseVisualStyleBackColor = True
        '
        'rbMBWay
        '
        Me.rbMBWay.AutoSize = True
        Me.rbMBWay.Location = New System.Drawing.Point(12, 78)
        Me.rbMBWay.Name = "rbMBWay"
        Me.rbMBWay.Size = New System.Drawing.Size(63, 17)
        Me.rbMBWay.TabIndex = 2
        Me.rbMBWay.TabStop = True
        Me.rbMBWay.Text = "MBWay"
        Me.rbMBWay.UseVisualStyleBackColor = True
        '
        'rbMB
        '
        Me.rbMB.AutoSize = True
        Me.rbMB.Location = New System.Drawing.Point(12, 54)
        Me.rbMB.Name = "rbMB"
        Me.rbMB.Size = New System.Drawing.Size(41, 17)
        Me.rbMB.TabIndex = 1
        Me.rbMB.TabStop = True
        Me.rbMB.Text = "MB"
        Me.rbMB.UseVisualStyleBackColor = True
        '
        'rbDinheiro
        '
        Me.rbDinheiro.AutoSize = True
        Me.rbDinheiro.Location = New System.Drawing.Point(12, 30)
        Me.rbDinheiro.Name = "rbDinheiro"
        Me.rbDinheiro.Size = New System.Drawing.Size(64, 17)
        Me.rbDinheiro.TabIndex = 0
        Me.rbDinheiro.TabStop = True
        Me.rbDinheiro.Text = "Dinheiro"
        Me.rbDinheiro.UseVisualStyleBackColor = True
        '
        'PrintDocument1
        '
        '
        'FormPagamento
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(437, 330)
        Me.Controls.Add(Me.btnCancelar)
        Me.Controls.Add(Me.btnImprimir)
        Me.Controls.Add(Me.dgvProdPg)
        Me.Controls.Add(Me.tbTotPagamento)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.gbDadosCliente)
        Me.Controls.Add(Me.gbPagamentos)
        Me.Name = "FormPagamento"
        Me.Text = "Pão Quente - Pagamento"
        CType(Me.dgvProdPg, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gbDadosCliente.ResumeLayout(False)
        Me.gbDadosCliente.PerformLayout()
        Me.gbPagamentos.ResumeLayout(False)
        Me.gbPagamentos.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnCancelar As Button
    Friend WithEvents btnImprimir As Button
    Friend WithEvents dgvProdPg As DataGridView
    Friend WithEvents tbTotPagamento As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents gbDadosCliente As GroupBox
    Friend WithEvents tbNome As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents mtbNIF As MaskedTextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents gbPagamentos As GroupBox
    Friend WithEvents rbCredito As RadioButton
    Friend WithEvents rbMBWay As RadioButton
    Friend WithEvents rbMB As RadioButton
    Friend WithEvents rbDinheiro As RadioButton
    Friend WithEvents PrintDocument1 As Printing.PrintDocument
End Class
