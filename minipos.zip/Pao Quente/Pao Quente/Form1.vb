﻿Public Class Form1

    Public pagamentoEfetuado As Boolean = False

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        tbTotal.ReadOnly = True
        InicializarGrid()
    End Sub
    Private Sub InicializarGrid()
        With dgvProduto
            .RowHeadersVisible = False
            .AllowUserToAddRows = False
            .AllowUserToDeleteRows = False
            .AllowUserToResizeColumns = False
            .AllowUserToResizeRows = False
            .MultiSelect = False
            .ReadOnly = True
            .Columns.Add("Quantidade", "Qtd")
            .Columns.Add("Produto", "Produto")
            .Columns.Add("preco", "P.Unt")
            .Columns.Add("total", "Total")
            .Font = New Font("Tahoma", 10.25)
            .Columns(0).Width = 40
            .Columns(1).Width = 147
            .Columns(2).Width = 50
            .Columns(3).Width = 50
            .Columns(0).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
            .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
            .Columns(1).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
            .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
            .Columns(2).HeaderCell.Style.Alignment = DataGridViewContentAlignment.TopRight
            .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopRight
            .Columns(3).HeaderCell.Style.Alignment = DataGridViewContentAlignment.TopRight
            .Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopRight

        End With
    End Sub
    Sub InserirLinha(produto As String, preco As Double)

        Dim tot As Double = preco
        Dim quantidade As Integer = 1
        Dim existeItem As Boolean
        existeItem = False

        'verifica na lista se o produto existe
        For Each row As DataGridViewRow In dgvProduto.Rows
            If Not row.IsNewRow Then
                'se o produto existir, incrementa a quantidade e o preço
                If row.Cells(1).Value.ToString.Equals(produto) Then
                    existeItem = True
                    row.Cells(0).Value = CInt("0" + row.Cells(0).Value) + quantidade
                    row.Cells(2).Value = Format(preco, "0.00")
                    row.Cells(3).Value = Format(CDbl("0" + row.Cells(3).Value) + tot, "0.00")
                    'dgvProduto.Refresh()
                End If
            End If
        Next

        'se não for encontrado produto, inclui na lista
        If Not existeItem Then
            dgvProduto.Rows.Add(quantidade, produto, Format(preco, "0.00"), Format(tot, "0.00"))
        End If

        'incrementa o total
        tbTotal.Text = Format(CDbl("0" + tbTotal.Text) + tot, "0.00")

    End Sub

    Private Sub btnCafe_Click(sender As Object, e As EventArgs) Handles btnCafe.Click
        InserirLinha(btnCafe.Text, 0.65)
    End Sub

    Private Sub btnPao_Click(sender As Object, e As EventArgs) Handles btnPao.Click
        InserirLinha(btnPao.Text, 0.5)
    End Sub

    Private Sub btnRissol_Click(sender As Object, e As EventArgs) Handles btnRissol.Click
        InserirLinha(btnRissol.Text, 1.2)
    End Sub

    Private Sub btnPastel_Click(sender As Object, e As EventArgs) Handles btnPastel.Click
        InserirLinha(btnPastel.Text, 1.0)
    End Sub

    Private Sub btnBolo_Click(sender As Object, e As EventArgs) Handles btnFinos.Click
        InserirLinha(btnFinos.Text, 1.5)
    End Sub

    Private Sub btnQueque_Click(sender As Object, e As EventArgs) Handles btnBolos.Click
        InserirLinha(btnBolos.Text, 0.8)
    End Sub

    Private Sub btnDrink_Click(sender As Object, e As EventArgs) Handles btnCocktails.Click
        InserirLinha(btnCocktails.Text, 2.5)
    End Sub

    Private Sub btnSumo_Click(sender As Object, e As EventArgs) Handles btnSumo.Click
        InserirLinha(btnSumo.Text, 1.8)
    End Sub

    Private Sub btnCafe_MouseHover(sender As Object, e As EventArgs) Handles _
        btnPao.MouseHover, btnCafe.MouseHover, btnFinos.MouseHover, btnCocktails.MouseHover, btnSumo.MouseHover,
        btnRissol.MouseHover, btnPastel.MouseHover, btnBolos.MouseHover
        Dim btn As Button
        btn = CType(sender, Button)
        btn.Image = My.Resources.Fundo
    End Sub

    Private Sub btnCafe_MouseLeave(sender As Object, e As EventArgs) Handles btnCafe.MouseLeave
        btnCafe.Image = My.Resources.cafe
    End Sub

    Private Sub btnPao_MouseLeave(sender As Object, e As EventArgs) Handles btnPao.MouseLeave
        btnPao.Image = My.Resources.Pao
    End Sub

    Private Sub btnRissol_MouseLeave(sender As Object, e As EventArgs) Handles btnRissol.MouseLeave
        btnRissol.Image = My.Resources.rissol
    End Sub

    Private Sub btnPastel_MouseLeave(sender As Object, e As EventArgs) Handles btnPastel.MouseLeave
        btnPastel.Image = My.Resources.pastel
    End Sub

    Private Sub btnBolo_MouseLeave(sender As Object, e As EventArgs) Handles btnFinos.MouseLeave
        btnFinos.Image = My.Resources.bolo1
    End Sub

    Private Sub btnQueque_MouseLeave(sender As Object, e As EventArgs) Handles btnBolos.MouseLeave
        btnBolos.Image = My.Resources.queque
    End Sub
    Private Sub btnDrink_MouseLeave(sender As Object, e As EventArgs) Handles btnCocktails.MouseLeave
        btnCocktails.Image = My.Resources.bebidas11
    End Sub

    Private Sub btnSumo_MouseLeave(sender As Object, e As EventArgs) Handles btnSumo.MouseLeave
        btnSumo.Image = My.Resources.sumo
    End Sub
    Private Sub dgvProduto_CellDoubleClick_1(sender As Object, e As DataGridViewCellEventArgs) Handles dgvProduto.CellDoubleClick

        Dim res As DialogResult

        Dim produto As String
        Dim preco As Double
        Dim quant As String
        Dim tot As Double

        If dgvProduto.RowCount > 0 Then

            produto = dgvProduto.Item(1, dgvProduto.CurrentRow.Index).Value
            quant = dgvProduto.Item(0, dgvProduto.CurrentRow.Index).Value
            preco = dgvProduto.Item(2, dgvProduto.CurrentRow.Index).Value
            tot = dgvProduto.Item(3, dgvProduto.CurrentRow.Index).Value
            res = MessageBox.Show("Deseja retirar o item """ + produto + """?", "Pão Quente",
            MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2)
            If res = DialogResult.Yes Then
                If quant > 1 Then
                    Dim row As DataGridViewRow = dgvProduto.CurrentRow
                    row.Cells(0).Value = CInt("0" + row.Cells(0).Value) - 1
                    row.Cells(3).Value = Format(CDbl("0" + row.Cells(3).Value) - preco, "0.00")
                    tbTotal.Text = Format(CDbl("0" + tbTotal.Text) - preco, "0.00")
                Else
                    dgvProduto.Rows.Remove(dgvProduto.CurrentRow)
                    tbTotal.Text = Format(CDbl("0" + tbTotal.Text) - tot, "0.00")
                End If

            End If
        End If
    End Sub

    Private Sub btnPagamento_Click(sender As Object, e As EventArgs) Handles btnPagamento.Click
        Dim pg As New FormPagamento
        'Dim produto As String
        'Dim preco As Double

        If tbTotal.Text.Length() = 0 Then
            MessageBox.Show("Lista Vazia!!!", "Pão Quente", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Exit Sub
        End If

        With pg
            .dgvProdPg.Columns.Add("Produto", "Produto")
            .dgvProdPg.Columns.Add("Quantidade", "Qtd")
            .dgvProdPg.Columns.Add("P.Unit", "P.Und")
            .dgvProdPg.Columns.Add("Preco", "Total")
        End With
        For Each row As DataGridViewRow In dgvProduto.Rows
            'produto = row.Cells(1).Value
            'preco = getPrecoUnit(produto)
            pg.dgvProdPg.Rows.Add(row.Cells(1).Value, row.Cells(0).Value, row.Cells(2).Value, row.Cells(3).Value)
        Next

        pg.tbTotPagamento.Text = tbTotal.Text
        pg.ShowDialog()

        If pagamentoEfetuado = True Then
            tbTotal.Text = Format(0.0, "")
            dgvProduto.Rows.Clear()
            pagamentoEfetuado = False
        End If

    End Sub
End Class
